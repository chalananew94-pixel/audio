# LinkGen — Admin-Only Link Generator

A protected link generator with a 2-step ad verification flow. Admins create short URLs; users must click through two advertisement links before reaching the destination.

## Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Copy example env file
cp .env.example .env

# 3. Edit .env — set your admin password and secrets
nano .env

# 4. Start the server
npm start
```

## Pages

| URL | Description |
|-----|-------------|
| `/login.html` | Admin login (password only) |
| `/admin.html` | Admin dashboard |
| `/go/:shortId` | Public verification page |

## Admin Dashboard Sections

- **Dashboard** — Stats (total links, active, views) + recent links
- **Create Link** — Generate a new short URL with image, title, ad links, destination
- **Generated Links** — View, search, edit, enable/disable, delete links
- **Settings** — Site name, logo, favicon, theme colours, footer text

## Environment Variables

| Variable | Description |
|----------|-------------|
| `SESSION_SECRET` | Random string for session encryption |
| `ADMIN_PASS` | Admin login password |
| `DATABASE_URL` | PostgreSQL connection string |
| `PORT` | Server port (default: 5000) |

## Verification Flow

1. User opens `/go/SHORTID`
2. Clicks **UNLOCK** on Step 1 → ad link opens in new tab + 5s countdown
3. After 5s → Step 1 verified ✓, Step 2 unlocks
4. Clicks **UNLOCK** on Step 2 → second ad link + 5s countdown
5. After 5s → **GET LINK** button appears → opens destination URL

Verification state is saved in `sessionStorage` so page refresh doesn't reset completed steps.
